﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Insatller
{
    class Program
    {
        static void Main(string[] args)
        {
            Mutex _m = new Mutex(true);

            Mutex _instance;
            
           if( Mutex.TryOpenExisting("PIC", out _instance))
            {
                Console.WriteLine("Another Instance of Installer is Running....Kidly Close and Start Again");
                Thread.Sleep(5000);
                System.Environment.Exit(0);
            }
            else
            {
                _instance = new Mutex(true, "PIC");
                while (true)
                {
                    Console.WriteLine("Insatlling...............");
                    Thread.Sleep(1000);
                    Console.WriteLine("Press S to exit");
                    if (Console.ReadLine() == "S")
                    {
                        _instance.ReleaseMutex();
                        return;
                    }

                }

            }
        }
    }
}
