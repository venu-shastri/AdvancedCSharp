﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadingDemo
{
    //Signgleton
    // [System.Runtime.Remoting.Contexts.Synchronization]

    public static class MutexHanldes
    {
        public static Mutex _instanceCreate = new Mutex(false);
        public static Mutex _instanceUpdate = new Mutex(false);
        public static Mutex _instanceDelete = new Mutex(false);
        public static Mutex _instanceSelect = new Mutex(false);

        public static AutoResetEvent _signalFromCreate = new AutoResetEvent(false);//wait 
        public static AutoResetEvent _signalFromUpdate = new AutoResetEvent(false);
        public static AutoResetEvent _signalFromDelete = new AutoResetEvent(false);
        public static AutoResetEvent _signalFromSelect = new AutoResetEvent(false);


    }
    public class DAOClass  //:ContextBoundObject
    {
        private Object _syncObjOne = new object();
        private Object _syncObjTwo = new object();

        private DAOClass() { }
        public static readonly DAOClass Instance = new DAOClass();
        
        public void Create() {
            System.Threading.Monitor.Enter(_syncObjOne);
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("Create .....");
                System.Threading.Thread.Sleep(100);
            }
            System.Threading.Monitor.Exit(_syncObjOne);

        }
        public void Update() {

            lock (_syncObjOne)
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine("Update .....");
                    System.Threading.Thread.Sleep(1000);
                    if (i == 4)
                    {
                        return;
                    }
                }
            }
           
        }
        public void Delete() {
            System.Threading.Monitor.Enter(_syncObjOne);
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Delete .....");
                System.Threading.Thread.Sleep(400);
                
            }
            System.Threading.Monitor.Exit(_syncObjOne);

        }

        public void Select()
        {
            System.Threading.Monitor.Enter(_syncObjTwo);
            for (int i = 0; i < 40; i++)
            {
                Console.WriteLine("Select .....");
                System.Threading.Thread.Sleep(200);
            }
            System.Threading.Monitor.Exit(_syncObjTwo);
        }
        public void Sync()
        {
            System.Threading.Monitor.Enter(_syncObjTwo);
            for (int i=0;i<10;i++)
            {
                Console.WriteLine("Sync.....");
                System.Threading.Thread.Sleep(1000);
            }
            System.Threading.Monitor.Exit(_syncObjTwo);
        }
    }

    public class DAOClass_Mutex  //:ContextBoundObject
    {
       

        private DAOClass_Mutex() { }
        public static readonly DAOClass_Mutex Instance = new DAOClass_Mutex();

        public void Create()
        {
            MutexHanldes._instanceCreate.WaitOne();
            //Signal Main Thread
            MutexHanldes._signalFromCreate.Set();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Create .....");
                System.Threading.Thread.Sleep(100);
            }
            MutexHanldes._instanceCreate.ReleaseMutex();
            
            

        }
        public void Update()
        {
            MutexHanldes._instanceUpdate.WaitOne();
            MutexHanldes._signalFromUpdate.Set();
            for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine("Update .....");
                    System.Threading.Thread.Sleep(1000);
                   
                }
            MutexHanldes._instanceUpdate.ReleaseMutex();

        }
        public void Delete()
        {
            MutexHanldes._instanceDelete.WaitOne();
            MutexHanldes._signalFromDelete.Set();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Delete .....");
                System.Threading.Thread.Sleep(400);

            }
            MutexHanldes._instanceDelete.ReleaseMutex();

        }

        public void Select()
        {
            MutexHanldes._instanceSelect.WaitOne();
            MutexHanldes._signalFromSelect.Set();
            for (int i = 0; i < 40; i++)
            {
                Console.WriteLine("Select .....");
                System.Threading.Thread.Sleep(200);
            }
            MutexHanldes._instanceSelect.ReleaseMutex();
        }
        public void Sync()
        {
            Console.WriteLine("Sync Thread Awaiting For CRUD Operations to complete");
            //MutexHanldes._instanceTwo.WaitOne();
            Mutex.WaitAll(new WaitHandle[] { MutexHanldes._instanceCreate, MutexHanldes._instanceDelete,MutexHanldes._instanceSelect,MutexHanldes._instanceUpdate });
            Console.WriteLine("Sync Thread Recieved Signals  CRUD Operation Threads");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Sync.....");
                System.Threading.Thread.Sleep(1000);
            }
            MutexHanldes._instanceCreate.ReleaseMutex();
            MutexHanldes._instanceDelete.ReleaseMutex();
            MutexHanldes._instanceSelect.ReleaseMutex();
            MutexHanldes._instanceUpdate.ReleaseMutex();
        }
    }
    class Program
    {
        static void Main_old(string[] args)
        {
            Console.WriteLine($"{System.Threading.Thread.CurrentThread.ManagedThreadId } IsBackground Thread {System.Threading.Thread.CurrentThread.IsBackground}");
            System.Threading.Thread t1 = new System.Threading.Thread(DAOClass_Mutex.Instance.Create);
            System.Threading.Thread t2 = new System.Threading.Thread(DAOClass_Mutex.Instance.Select);
            System.Threading.Thread t3 = new System.Threading.Thread(DAOClass_Mutex.Instance.Update);
            System.Threading.Thread t4 = new System.Threading.Thread(DAOClass_Mutex.Instance.Delete);
            System.Threading.Thread t5 = new System.Threading.Thread(DAOClass_Mutex.Instance.Sync);
            //t4.IsBackground = true;

            t1.Start();
            t2.Start();
            t3.Start();
            t4.Start();
            
            WaitHandle.WaitAll(new WaitHandle[] { MutexHanldes._signalFromSelect, MutexHanldes._signalFromCreate, MutexHanldes._signalFromUpdate, MutexHanldes._signalFromDelete });
            Console.WriteLine("Received Signal From All CRUD Threads");
            t5.Start();

        }

        static void Main()
        {

            ThreadPool.QueueUserWorkItem((obj) => {
                DAOClass_Mutex.Instance.Create();
            });
            ThreadPool.QueueUserWorkItem((obj) => {
                DAOClass_Mutex.Instance.Select();
            });
            ThreadPool.QueueUserWorkItem((obj) => {
                DAOClass_Mutex.Instance.Update();
            });
            ThreadPool.QueueUserWorkItem((obj) => {
                DAOClass_Mutex.Instance.Delete();
            });
            WaitHandle.WaitAll(new WaitHandle[] { MutexHanldes._signalFromSelect, MutexHanldes._signalFromCreate, MutexHanldes._signalFromUpdate, MutexHanldes._signalFromDelete });
            Console.WriteLine("Received Signal From All Thread Pool CRUD Threads");

            ThreadPool.QueueUserWorkItem((obj) => {
                DAOClass_Mutex.Instance.Sync();
            });

            Console.ReadKey();
        }
    }
}
