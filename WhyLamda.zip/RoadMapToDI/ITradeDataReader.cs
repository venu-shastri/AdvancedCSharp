﻿using System.Collections.Generic;

namespace RoadMapToDI
{
    public interface ITradeDataReader
    {
        List<TradeRecord> GeTradeRecords();
    }
}