﻿namespace RoadMapToDI
{
    public interface ICSVTradeRecordeLineValidator
    {
        bool Validate(string line);
    }
}