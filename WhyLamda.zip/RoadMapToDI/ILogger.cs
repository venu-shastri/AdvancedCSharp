﻿namespace RoadMapToDI
{
    public interface ILogger
    {
        void Write(string message);
    }
}