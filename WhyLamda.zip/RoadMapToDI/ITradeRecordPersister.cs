﻿using System.Collections.Generic;

namespace RoadMapToDI
{
    public interface ITradeRecordPersister
    {
        bool Persist(List<TradeRecord> trades);
    }
}