﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

namespace RoadMapToDI
{
  
    [Export(typeof(ILogger))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ConsoleLogger : ILogger
    {
        public void Write(string message)
        {
            Console.Write(message);
        }
    }
    //Program for interface not for implementation
    [Export(typeof(ICSVTradeRecordeLineValidator))]
    public class CSVTradeRecordeLineValidator : ICSVTradeRecordeLineValidator
    {
        ILogger _logger;
        [ImportingConstructor]
        public CSVTradeRecordeLineValidator(ILogger logger)
        {
            this._logger = logger;

        }
        public bool Validate(string line)
        {
            bool isValid = true;
            var fields = line.Split(new char[] { ',' });

            if (fields.Length != 3)
            {
                isValid = false;
                this._logger.Write(string.Format("WARN:  Only {0} field(s) found.", fields.Length));

            }

            if (fields[0].Length != 6)
            {
                isValid = false;
                this._logger.Write(string.Format("WARN: Trade currencies malformed:{0}", fields[0]));

            }

            int tradeAmount;
            if (!int.TryParse(fields[1], out tradeAmount))
            {
                isValid = false;
                this._logger.Write(string.Format("WARN: Trade amount is  not a valid integer'{0}'", fields[1]));
            }

            decimal tradePrice;
            if (!decimal.TryParse(fields[2], out tradePrice))
            {
                isValid = false;
                this._logger.Write(string.Format("WARN: Trade price is not a valid decimal:'{0}'", fields[2]));
            }
            return isValid;
        }
    }


    [Export(typeof(ITradeDataReader))]
    public class CSVTradeDataReader : ITradeDataReader
    {
        //System.IO.Stream _stream;
       public System.IO.Stream Stream { get; set; }
        ICSVTradeRecordeLineValidator _validator;
        [ImportingConstructor]
        public CSVTradeDataReader(ICSVTradeRecordeLineValidator validator)
        {
          //  this._stream = stream;
            this._validator = validator;

        }
       public List<TradeRecord> GeTradeRecords()
        {
            var lines = new List<string>();
            using (var reader = new System.IO.StreamReader(this.Stream))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    lines.Add(line);
                }
            }

            var trades = new List<TradeRecord>();
            foreach (var line in lines)
            {
                if (this._validator.Validate(line))
                {
                    ///
                }
            }
            return trades;
        }

    }

    [Export(typeof(ITradeRecordPersister))]
    public class TradeRecordDBPersister : ITradeRecordPersister
    {
        ILogger _logger;
        [ImportingConstructor]
        public TradeRecordDBPersister(ILogger logger)
        {
            this._logger = logger;
        }
        public bool Persist(List<TradeRecord> trades)
        {
            using (var connection = new System.Data.SqlClient.SqlConnection("DatSource = (local); Initial Catalog = TradeDatabase; Integrated Security = True"))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    foreach (var trade in trades)
                    {
                        var command = connection.CreateCommand();
                        command.Transaction = transaction;
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.CommandText = "dbo.insert_trade";
                        command.Parameters.AddWithValue("@sourceCurrency", trade.
      SourceCurrency);
                        command.Parameters.AddWithValue("@destinationCurrency", trade.
      DestinationCurrency);
                        command.Parameters.AddWithValue("@lots", trade.Lots);
                        command.Parameters.AddWithValue("@price", trade.Price);

                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                connection.Close();
            }

       this._logger.Write(string.Format("INFO: {0} trades processed", trades.Count));
            return true;
        }
    }

    [Export(typeof(TradeProcessor))]
    public class TradeProcessor
    {
        ITradeDataReader _reader;
        ITradeRecordPersister _persister;
        
        [ImportingConstructor]
        public TradeProcessor(ITradeDataReader reader,ITradeRecordPersister persister)
        {
            this._reader = reader;
            this._persister = persister;
        }
        public void ProcessTrades()
        {
            this._persister.Persist(this._reader.GeTradeRecords());
            
        }

        
    }




   public  class TradeRecord
    {
        public string SourceCurrency { get; set; }

        public string DestinationCurrency { get; set; }

        public float Lots { get; set; }

        public decimal Price { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Catalog
            AssemblyCatalog _catalog =
                new AssemblyCatalog(System.Reflection.Assembly.GetExecutingAssembly());
            //DiContainer Instance
            CompositionContainer _diContainer = new CompositionContainer(_catalog);

           TradeProcessor _procressor= _diContainer.GetExportedValue<TradeProcessor>();

        }
    }
}
