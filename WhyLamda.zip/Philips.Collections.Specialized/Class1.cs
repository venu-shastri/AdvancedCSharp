﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.Collections.Specialized
{
    //Subject
    public class ObservableCollection<T>
    {
      
        List<T> _internalList = new List<T>();

        //events
        public event Action<T> OnNewItemAdded;
        public event Action<T> OnItemRemoved;
        public event Action OnListEmpty;


        public void Add(T item)
        {
            _internalList.Add(item);
            if (OnNewItemAdded != null)
            {
                //Event Raise
                OnNewItemAdded.Invoke(item);
            }
        }

        public bool Remove(T item)
        {
            bool isItemRemoved= _internalList.Remove(item);
            if(isItemRemoved)
            {
                if(OnItemRemoved!=null)
                {
                    OnItemRemoved.Invoke(item);
                }
            }
            return isItemRemoved;
        }
        public void Clear()
        {
            _internalList.Clear();
            if (OnListEmpty != null)
            {
                OnListEmpty.Invoke();
            }
        }
    }
}
