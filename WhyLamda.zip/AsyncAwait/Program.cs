﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncAwait
{
    class Program
    {
        static System.Threading.AutoResetEvent _event = new System.Threading.AutoResetEvent(false);

        static void Main(string[] args)
        {
            // Test();
            InitiateNetworkRequest();
            _event.WaitOne();
            
        }
        //Validate Method
        //Return Type= void|Task
        //awit statement
        static async void Test()
        {
            Console.WriteLine("Epidsode 1 : Ahead of Await Staement");
            string result=await Task.Run<string>(() => {
                return "Episode 2 : Test Result";
            });
            Console.WriteLine("Episode 3:After Await Completion");
            Console.WriteLine(result);
            result = await Task.Run<string>(() => {
                return "Episode 4: Test Result";
            });
            Console.WriteLine("Episode 5:After Await Completion");
            Console.WriteLine(result);

        }
        static async void InitiateNetworkRequest()
        {
            System.Net.Http.HttpClient httpClient = new System.Net.Http.HttpClient();
            
          System.Net.Http.HttpResponseMessage message= await httpClient.GetAsync("http://www.google.com");
            if(message.StatusCode==System.Net.HttpStatusCode.OK)
            {
                string content = await message.Content.ReadAsStringAsync();
                Console.WriteLine(content);
            }
          
        }
    }

}
