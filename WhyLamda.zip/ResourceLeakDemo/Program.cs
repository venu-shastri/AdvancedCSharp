﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ResourceLeakDemo
{
    public enum ResourceState
    {
        FREE,BUSY
    }
    public static class Resource
    {
        public static string State = "free";
    }
    public static class SynchronizationHelper
        {
        public static object _syncObj = new object();
        public static AutoResetEvent _signal = new AutoResetEvent(false);
       
        }
    public class ResourceWrapper:IDisposable
    {
        bool isDisposed = false;

        public ResourceWrapper()
        {
            lock (SynchronizationHelper._syncObj)
            {
                if (Resource.State == "free")
                {
                    Resource.State = "busy";
                    Console.WriteLine($"Resource Owned By {Thread.CurrentThread.Name} ");
                }
                else
                {
                    Console.WriteLine($"{Thread.CurrentThread.Name} awaiting for Resource Release");
                    SynchronizationHelper._signal.WaitOne();
                    Resource.State = "busy";
                    Console.WriteLine($"Resource Owned By {Thread.CurrentThread.Name} ");
                }
            }
        }
        public void UseResource()
        {
            if (isDisposed)
            {
                throw new ObjectDisposedException("ResourceWrapper Disposed");
            }
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Resource used By {Thread.CurrentThread.Name} ");
                Thread.Sleep(1000);
            }
        }

        protected void Dispose(bool isDisposing)
        {
            if (!isDisposed)
            {
                //Dispose Method
                if (isDisposing)
                {
                    Console.WriteLine($"Resource Released By {Thread.CurrentThread.Name} using Dispose Method ");
                    isDisposed = true;
                    GC.SuppressFinalize(this);
                    
                }
                else
                {
                    //Call From Finalize
                    Console.WriteLine($"Resource Released By Finalize Method ");

                }
                Cleanup();
            }
        }
        void Cleanup()
        {
            Resource.State = "free";
            SynchronizationHelper._signal.Set();

        }
        public void Dispose()
        {

            Dispose(true);
            
        }

        ~ResourceWrapper()
        {
            Dispose(false);

        }

    }
    class Program
    {
        static void Main(string[] args)
        {

            new Thread(Client) { Name = "T1" }.Start();
            new Thread(Client) { Name = "T2" }.Start();
            //Client();
        }

        static void Client()
        {
            //ResourceWrapper rw = new ResourceWrapper();
            //try
            //{
            //    rw.UseResource();
            //}
            //finally
            //{
            //    if(rw is IDisposable)
            //    {
            //        rw.Dispose();
            //    }
            //}
            //rw = null;

            using (ResourceWrapper rw=new ResourceWrapper ())
            {
                rw.UseResource();
            }

        }


    }
}
