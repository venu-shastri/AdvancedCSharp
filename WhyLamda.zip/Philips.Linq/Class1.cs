﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.Linq
{
    public static  class EnumerableCollections
    {
        public static IEnumerable<TSource> Where<TSource>(this IEnumerable<TSource> source,
           Func<TSource, bool> predicate)
        {
            foreach(TSource item in source)
            {
                if (predicate.Invoke(item))
                {
                    yield return item;
                }
            }

        }
        public static IEnumerable<TSource> NextWhere<TSource>(this IEnumerable<TSource> source,
           Func<TSource, bool> predicate)
        {
            foreach (TSource item in source)
            {
                if (predicate.Invoke(item))
                {
                    yield return item;
                }
            }

        }
        public static IEnumerable<TSource> NewWhere<TSource>(this IEnumerable<TSource> source,
           Func<TSource, bool> predicate)
        {
            foreach (TSource item in source)
            {
                if (predicate.Invoke(item))
                {
                    yield return item;
                }
            }

        }
    }
}
