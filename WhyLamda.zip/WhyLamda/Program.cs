﻿using System;
using System.Collections.Generic;
//using System.Linq;
using Philips.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhyLamda
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] names = { "abc", "xyz", "pqrs", "tuv" };

            //Philips.Linq.EnumerableCollections.Where<string>(
            //    names,
            //    (name) => { return name.Length > 10; });

            //names.Where<string>((item) => { return item.Length < 10; });
            ////Philips.Linq.EnumerableCollections.Where<string>( names,
            //names.Where().NewWhere().NextWhere()

            Philips.Collections.Specialized.ObservableCollection<string> _colletion = 
                new Philips.Collections.Specialized.ObservableCollection<string>();

            Action<string> subscriberRef = (item) => { Console.WriteLine($"New Item {item} insterted"); };
            _colletion.OnNewItemAdded += subscriberRef;

            _colletion.Add("One");
            _colletion.Add("Two");
            _colletion.Add("Three");
            _colletion.OnNewItemAdded -= subscriberRef;

            _colletion.Add("Four");
            _colletion.Add("Five");

            _colletion.Remove("one");


        }

    }
}