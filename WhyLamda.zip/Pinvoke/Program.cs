﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pinvoke
{
    /* Declare API Function */

        
    class Program
    {
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        public static extern uint GetCurrentThreadId();

        static void Main(string[] args)
        {
            string message = $"Current OS thread Id {GetCurrentThreadId()} and Managed Thread {System.Threading.Thread.CurrentThread.ManagedThreadId}";
            Console.WriteLine(message);
               
        }
    }
}
