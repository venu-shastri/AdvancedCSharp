﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCDemo
{
    class A
    {
        B obj = new B();
        public int getGenerationOFB()
        {
            return GC.GetGeneration(this.obj);

        }
    }
    class B
    {

    }
    class Program
    {
        static A objRef;
        static void Main(string[] args)
        {
            Allocate();
        }
        static void Allocate()
        {
            A obj = new A();//GC Generation - 0
            Program.objRef = obj;
            List<A> list = new List<A>();
            list.Add(obj);

            GC.Collect(0);
            GC.Collect(1);
            GC.Collect(2);//A and B removed
            obj = null;
            GC.Collect();




        }
    }
}
