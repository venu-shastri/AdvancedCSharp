﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;//TPL
using System.Collections.Concurrent;

namespace TPLDemo
{
    class Program
    {
        static void Main_old(string[] args)
        {
            Task<string> _asyncTask = new Task<string>(()=> {

                string messgae = $"Are You ThreadPool {System.Threading.Thread.CurrentThread.IsThreadPoolThread}";
                Console.WriteLine(messgae);
                int sum = default(int);
                for (int i = 0; i < 10; i++)
                {
                    Console.WriteLine("Async Task One " + i);
                    System.Threading.Thread.Sleep(5000);
                    if (i == 5)
                    {
                        throw new Exception("Async Task Exception");
                    }

                    sum += i;
               

                }
                return sum.ToString();

            });

            _asyncTask.Start();
            //_asyncTask.Wait();
            try
            {
                Console.WriteLine(_asyncTask.Result);
            }
            catch(AggregateException ex)
            {
                Console.WriteLine(ex.InnerException.Message);
            }
            Console.WriteLine(_asyncTask.Status);
        

          
        }

        static void Main_ParentChild()
        {
            Task _parentTask = new Task(() => {

                Console.WriteLine("Parent Task Begin");
                Task _detachedTask = new Task(() => {
                    Console.WriteLine("Detached Task Begin");
                    Task childTask = new Task(()=> {
                        Console.WriteLine("Child Task Begin");
                        for (int i = 0; i < 20; i++)
                        {
                            Console.WriteLine("Child Task in Excecution");
                            System.Threading.Thread.Sleep(1000);
                            if(i==10)
                            {
                                throw new Exception("Child Task Exception");
                            }
                        }
                        Console.WriteLine("Child Task End");
                    },TaskCreationOptions.AttachedToParent);
                    childTask.Start();
                    for(int i=0;i<10;i++)
                    {
                        Console.WriteLine("Detached Task in Excecution");
                        System.Threading.Thread.Sleep(1000);
                        if (i == 5)
                        {
                            throw new Exception("Detached Task Exception");
                        }
                    }
                    Console.WriteLine("Detached Task End");

                },TaskCreationOptions.AttachedToParent);
                _detachedTask.Start();
                Console.WriteLine("Parent Task End");

            });

            _parentTask.Start();
            try
            {
                _parentTask.Wait();
            }
            catch(AggregateException ex)
            {
                var exceptions=ex.Flatten().InnerExceptions;
                foreach(var exception in exceptions)
                {
                    Console.WriteLine(exception.Message);
                }

            }
        }

        static void Main()
        {
            


            while (true)
            {
                Console.WriteLine("Press any key to send N/W request");
                Console.ReadKey();

                Task<string> _networkRequestTask = new Task<string>(() => {

                    string message = string.Empty;
                    Console.WriteLine("Network Start Begin");
                    System.Threading.Thread.Sleep(5000);
                    Random _random = new Random();
                    if (_random.Next(0, 9) % 2 == 0)
                    {
                        message = "NetWork Request Task Completed";
                    }
                    else
                    {
                        message = "Netwrok Error";
                        throw new Exception(message);
                    }
                    return message;

                });

                Task<string> _processResultTask = _networkRequestTask.ContinueWith<string>((pt) =>
                {

                    Console.WriteLine("Process Result Task  Begin");
                    System.Threading.Thread.Sleep(5000);
                    return $"{pt.Result}:: ProcessResult Task Completed";

                }, TaskContinuationOptions.OnlyOnRanToCompletion | TaskContinuationOptions.NotOnFaulted);

                Task<string> normalizeTask = _processResultTask.ContinueWith<string>((pt) => {

                    Console.WriteLine("Normalize Task  Begin");
                    System.Threading.Thread.Sleep(5000);
                    return $"{pt.Result} :: Normailze Task Completed ";

                }, TaskContinuationOptions.NotOnFaulted | TaskContinuationOptions.OnlyOnRanToCompletion);

                normalizeTask.ContinueWith((pt) => {
                    Console.WriteLine("Update UI Task  Begin");
                    System.Threading.Thread.Sleep(5000);
                    Console.WriteLine(pt.Result);

                    Console.WriteLine("Update UI Task Completed");
                },TaskContinuationOptions.NotOnFaulted|TaskContinuationOptions.OnlyOnRanToCompletion);
                normalizeTask.ContinueWith((pt) => {

                    Console.WriteLine("DataLog Update Task  Begin");
                    System.Threading.Thread.Sleep(5000);
                    Console.WriteLine(pt.Result);

                    Console.WriteLine("DataLog Update Task  Completed");

                }, TaskContinuationOptions.NotOnFaulted | TaskContinuationOptions.OnlyOnRanToCompletion);

                _networkRequestTask.ContinueWith((pt) => {

                    Console.WriteLine("Error Log  Task  Begin");
                    System.Threading.Thread.Sleep(5000);
                    Console.WriteLine($"Error Task End : {pt.Exception.InnerException.Message}");

                }, TaskContinuationOptions.OnlyOnFaulted);
                _networkRequestTask.Start();
            }
        }
    }
}
