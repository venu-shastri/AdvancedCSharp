﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoggerSuiteLib
{
    //abstraction
   abstract class ValidationAtrribute:System.Attribute
    {
        public abstract bool Validate(object value);

    }

    //Low Level Module
    class MaxLengthValidatorAttribute:ValidationAtrribute
    {
        public int MaxLength { get; set; }

        public override  bool Validate(object value)
        {
            string data=value as string;
            if(data.Length < MaxLength)
            {
                return true;
            }
            return false;

        }


    }




    [AttributeUsage(AttributeTargets.Class,AllowMultiple =false)]
    class SingletonAttribute : System.Attribute
    {

    }

    public interface ILogger
    {
        void Write(string message);
    }

     [Singleton]
     class ConsoleLogger : ILogger
    {
        public ConsoleLogger()
        {
            Console.WriteLine("ConsoleLogger Instantiated");
        }
        
        [MaxLengthValidator(MaxLength =10)]
        public void Write(string message)
        {
            Console.WriteLine($"Console Logger {message}");
        }
    }
     class FileLogger : ILogger
    {

        public FileLogger()
        {
            Console.WriteLine("FileLogger Instantiated");
        }
        public void Write(string message)
        {
            Console.WriteLine($"File Logger {message}");
        }
    }

    //dependency Inversion Principle

        //HighLavel Module
    class LoggerProxy : ILogger
    {
        ILogger _actualLoggerRef;
        public LoggerProxy(ILogger actualLogger)
        {
            this._actualLoggerRef = actualLogger;
        }
        public void Write(string message)
        {
            //validation
            //Reflection 
            if(_actualLoggerRef.GetType().GetMethod(nameof(Write)).
                IsDefined(typeof(ValidationAtrribute), true))
            {
                ValidationAtrribute[] attributes =
                     _actualLoggerRef.
              GetType().
              GetMethod("Write").
              GetCustomAttributes(typeof(ValidationAtrribute), true) as ValidationAtrribute[];

                foreach(ValidationAtrribute attribute in attributes)
                {
                   
                        if (attribute.Validate(message))
                        {
                            this._actualLoggerRef.Write(message);
                        }
                        else
                        {
                            throw new InvalidOperationException("Validation Error");
                        }
                    }
                }


            }
        }
    

    public class LoggerFactory
    {
        Dictionary<string, ILogger> _singletonStore = new Dictionary<string, ILogger>();
        public static readonly LoggerFactory Instance = new LoggerFactory();
        private LoggerFactory()
        {

        }

        public ILogger GetLoggerInstance(string logType)
        {
            ILogger _loggerInstance = default(ILogger);
            var types =
                System.Reflection.Assembly.GetExecutingAssembly().GetTypes();
           
            foreach(var type in types)
            {
                               if (type.IsClass && 
                    !type.IsAbstract && 
                    type.GetInterface("ILogger")!=null && 
                    type.Name.StartsWith(logType) &&
                    type.Name.EndsWith("Logger"))
                {
                    if (type.IsDefined(typeof(SingletonAttribute), true)){

                        if(!_singletonStore.ContainsKey(logType))
                        {
                          var   instance = System.Activator.CreateInstance(type) as ILogger;
                            _singletonStore[logType] = instance;
                            _loggerInstance = instance;
                            return new LoggerProxy( _loggerInstance);

                        }
                        else
                        {
                            _loggerInstance = _singletonStore[logType];
                            return new LoggerProxy( _loggerInstance);
                        }
                    }
                 _loggerInstance= System.Activator.CreateInstance(type) as ILogger;
                    return new LoggerProxy( _loggerInstance);

                }
            }

            return new LoggerProxy( _loggerInstance);
        }

    }
}
